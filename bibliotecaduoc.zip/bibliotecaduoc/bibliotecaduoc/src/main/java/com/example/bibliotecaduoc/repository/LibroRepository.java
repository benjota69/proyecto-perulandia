package com.example.bibliotecaduoc.repository;

import com.example.bibliotecaduoc.model.Libro;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.ArrayList;

@Repository
public class LibroRepository {

    private List<Libro> listaLibros = new ArrayList<>();

    public List<Libro> obtenerLibros(){
        return listaLibros;
    }

    public Libro buscarPorId(int id){
        for (Libro libro : listaLibros) {
            if (libro.getId()==id) {
                return libro;  
            }
        }
        return null;
    }

    public Libro buscarPorIsbn(String isbn){
        for (Libro libro : listaLibros) {
            if (libro.getIsbn().equals(isbn)) {
                return libro;
            }
        }
        return null;
    }

    public Libro guardar(Libro libro){
        listaLibros.add(libro);
        return libro;
    }

    public Libro actualizar(Libro libro){
        int id=0;
        int idPosicion=0;

        for(int i=0;i<listaLibros.size();i++){
            if (listaLibros.get(i).getId()==libro.getId()) {
                id = libro.getId();
                idPosicion=1;
            }
        }

        Libro libro1 = new Libro();
        libro1.setId(id);
        libro1.setTitulo(libro.getTitulo());
        libro1.setAutor(libro.getAutor());
        libro1.setFechaPublicacion(libro.getFechaPublicacion());
        libro1.setEditorial(libro.getEditorial());
        libro1.setIsbn(libro.getIsbn());

        listaLibros.set(idPosicion, libro1);
        return libro1;

    }

    public void eliminar(int id){
        Libro libro = buscarPorId(id);
        if (libro!=null) {
            listaLibros.remove(libro);
        }
    }
    
}
